package com.qolmod.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Bubble ">_" yang digambar manual supaya posisinya pas di tengah lingkaran. */
class BubbleView(context: Context) : View(context) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE0243C.toInt() }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0x73FFFFFF
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val s = width.toFloat()
        ring.strokeWidth = s * 0.04f
        canvas.drawCircle(s / 2, s / 2, s / 2 - ring.strokeWidth, bg)
        canvas.drawCircle(s / 2, s / 2, s / 2 - ring.strokeWidth, ring)

        glyph.strokeWidth = s * 0.075f
        val h = s * 0.34f
        val a = s * 0.17f
        val gap = s * 0.08f
        val bw = s * 0.17f
        val totalW = a + gap + bw
        val ox = (s - totalW) / 2
        val oy = (s - h) / 2

        val p = Path().apply {
            moveTo(ox, oy)
            lineTo(ox + a, oy + h / 2)
            lineTo(ox, oy + h)
        }
        canvas.drawPath(p, glyph)
        canvas.drawLine(ox + a + gap, oy + h, ox + totalW, oy + h, glyph)
    }
}
